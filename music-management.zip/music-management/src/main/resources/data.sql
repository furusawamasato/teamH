INSERT INTO albums (title, artist, release_date) VALUES
    ('Hello World', 'Aurora Beats', '2021-08-20'),
    ('Strings of Serenity', 'Harmony Collective', '2020-11-10'),
    ('Cosmic Vibes', 'Galaxy Harmonics', '2024-01-18');


INSERT INTO musics (title, release_date, duration, place, album_id) VALUES
    ('Sunset', '2021-08-10', '00:00', 'A室', 1),
    ('Moonlight', '2021-07-10', '00:10', 'B室', 2),
    ('Eternal Memories', '2021-06-10',  '00:20', 'C室', 3);